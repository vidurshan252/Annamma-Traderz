ANNAMMA TRADERS — CUSTOM WEBSITE SETUP

Already filled in:
- WhatsApp: 0769218627 (WhatsApp link uses international number 94769218627)
- Phone: 0769218627
- Address: Kattaikadu Kottantivu
- Opening hours: 7 a.m. to 7 p.m.

Still to edit:
- Product names, descriptions, categories and prices in script.js
- Product photos in the images folder
- mapQuery in script.js if you know the more exact location / map listing

HOW TO CHANGE PRODUCT DETAILS
1. Open script.js in a text/code editor.
2. Find const PRODUCTS = [.
3. For each product, replace name, category and description.
4. Replace price with a number only (e.g. 250 for Rs. 250).
5. For a photo, add the file to images/ and set image: "images/your-file.jpg".
6. Keep the quotation marks and commas. Do not delete the braces or square brackets.
7. Save and refresh index.html preview.

NOTE: Until you edit PRODUCTS, the website displays clearly labelled sample items and sample prices. Do not publish those as real stock/prices.

ANDROID TESTING
- Download and extract the ZIP.
- Open index.html in a browser or in an HTML editor's Preview.
- Tap WhatsApp buttons to confirm they open a chat with the shop number.
- Test the call button and Google Maps link.

FREE PUBLISHING WITH GITHUB PAGES
1. Sign in at https://github.com and create a public repository named annamma-traders.
2. Upload index.html, style.css, script.js, and the images folder contents.
3. Go to repository Settings → Pages.
4. Select Deploy from a branch, branch main, folder /(root), then Save.
5. Wait for deployment and open the site URL shown in Pages settings.

This is a static catalogue site. Customers message the shop through WhatsApp; there is no built-in checkout, online payment, stock management or admin login.
