/*
  ANNAMMA TRADERS — SHOP SETTINGS
  WhatsApp number must use international format without +, spaces or leading 0.
  Sri Lanka number 0769218627 becomes 94769218627.
*/
const SHOP = {
  whatsapp: "94769218627",
  phone: "0769218627",
  address: "Kattaikadu Kottantivu",
  mapQuery: "Kattaikadu Kottantivu, Sri Lanka", // Edit to a more precise shop location if needed
  hours: "7 a.m. to 7 p.m.",
  currency: "LKR"
};

/*
  SAMPLE PRODUCTS — replace all six with your actual products.
  price is a number in LKR, e.g. 250 means Rs. 250.
  image: "images/rice.jpg" means put rice.jpg inside the images folder.
  If image is empty, a simple emoji placeholder appears.
*/
const PRODUCTS = [
  { id: 1, name: "Add Product Name 1", category: "Edit category", description: "Replace this with your product details.", price: 250, image: "", emoji: "🛍️" },
  { id: 2, name: "Add Product Name 2", category: "Edit category", description: "Replace this with your product details.", price: 450, image: "", emoji: "📦" },
  { id: 3, name: "Add Product Name 3", category: "Edit category", description: "Replace this with your product details.", price: 750, image: "", emoji: "🌿" },
  { id: 4, name: "Add Product Name 4", category: "Edit category", description: "Replace this with your product details.", price: 1200, image: "", emoji: "🎁" },
  { id: 5, name: "Add Product Name 5", category: "Edit category", description: "Replace this with your product details.", price: 950, image: "", emoji: "🧺" },
  { id: 6, name: "Add Product Name 6", category: "Edit category", description: "Replace this with your product details.", price: 600, image: "", emoji: "✨" }
];

const grid = document.getElementById("productGrid");
const searchInput = document.getElementById("searchInput");
const emptyState = document.getElementById("emptyState");

function formatPrice(price) {
  return new Intl.NumberFormat("en-LK", { style: "currency", currency: SHOP.currency, maximumFractionDigits: 2 }).format(price);
}
function makeWhatsAppLink(message) {
  const number = SHOP.whatsapp.replace(/\D/g, "");
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}
function renderProducts(query = "") {
  const q = query.trim().toLowerCase();
  const matches = PRODUCTS.filter(p => `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(q));
  grid.innerHTML = matches.map(p => {
    const imageMarkup = p.image
      ? `<img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.hidden=false"><span class="product-emoji" hidden>${p.emoji || "🛍️"}</span>`
      : `<span class="product-emoji">${p.emoji || "🛍️"}</span>`;
    const message = `Hello Annamma Traders! I would like to ask/order: ${p.name}. Listed price: ${formatPrice(p.price)}. Please confirm availability and final price.`;
    return `<article class="product-card">
      <div class="product-image">${imageMarkup}</div>
      <div class="product-info">
        <p class="product-category">${p.category}</p>
        <h3>${p.name}</h3>
        <p class="product-description">${p.description}</p>
        <div class="product-bottom"><span class="price">${formatPrice(p.price)}</span>
          <a class="order-button" href="${makeWhatsAppLink(message)}" target="_blank" rel="noopener">Order on WhatsApp ↗</a>
        </div>
      </div>
    </article>`;
  }).join("");
  emptyState.hidden = matches.length > 0;
}
function setupContact() {
  const hello = `Hello Annamma Traders! I would like to know more about your products.`;
  const wa = makeWhatsAppLink(hello);
  ["headerWhatsApp", "mainWhatsApp", "floatingWhatsApp"].forEach(id => {
    document.getElementById(id).href = wa;
  });
  document.getElementById("phoneText").textContent = SHOP.phone;
  document.getElementById("callLink").href = `tel:${SHOP.phone.replace(/[^\d+]/g, "")}`;
  document.getElementById("addressText").textContent = SHOP.address;
  document.getElementById("mapLink").href = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(SHOP.mapQuery)}`;
  document.getElementById("hoursText").textContent = SHOP.hours;
  document.getElementById("year").textContent = new Date().getFullYear();
}
searchInput.addEventListener("input", event => renderProducts(event.target.value));
setupContact();
renderProducts();
